#include "stm32f10x.h"
#include "encoders.h"
#include "math.h"

#define SPEED_COEFF 21
#define SPEED_COEFF_CUBE 0
#define ENC_COEFF 0.03
#define ENC_CONST 3

#define SPEED_COEFF_D 13
#define SPEED_COEFF_I 1.1


#ifdef __cplusplus
 extern "C" {
#endif
float vel1(float speed, long int enc1);
float vel2(float speed, long int enc2);
float vel3(float speed, long int enc3);
float vel4(float speed, long int enc4);

#ifdef __cplusplus
}
#endif