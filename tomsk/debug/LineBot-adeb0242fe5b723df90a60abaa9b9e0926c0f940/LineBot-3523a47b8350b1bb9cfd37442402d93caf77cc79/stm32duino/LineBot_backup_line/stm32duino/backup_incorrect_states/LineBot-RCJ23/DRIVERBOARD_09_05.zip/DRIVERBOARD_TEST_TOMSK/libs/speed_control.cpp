#include "speed_control.h"


float u1 = 0;

float up1 = 0;
float ud1 = 0;
float ui1 = 0;

float err1 = 0;
float err1_old = 0;

float u2 = 0;

float up2 = 0;
float ud2 = 0;
float ui2 = 0;

float err2 = 0;
float err2_old = 0;

float u3 = 0;

float up3 = 0;
float ud3 = 0;
float ui3 = 0;

float err3 = 0;
float err3_old = 0;

float u4 = 0;

float up4 = 0;
float ud4 = 0;
float ui4 = 0;

float err4 = 0;
float err4_old = 0;

float vel1(float speed, long int enc1)
{
	if (speed==100)
	{
		speed = 99;
	}
	if (speed==-100)
	{
		speed = -99;
	}
	
	err1 = speed*ENC_COEFF + (Encoder1()-enc1)*ENC_CONST;
	up1 = err1*SPEED_COEFF+err1*err1*err1*SPEED_COEFF_CUBE;
	ui1 = ui1 + err1*SPEED_COEFF_I;
	ud1 = (err1_old - err1)*SPEED_COEFF_D;
	u1 = up1+ui1+ud1;
	err1_old = err1;
	if (err1==0)
	{
		ui1 = 0;
		
	}
	return u1;
}
float vel2(float speed, long int enc2)
{
	if (speed==100)
	{
		speed = 99;
	}
	if (speed==-100)
	{
		speed = -99;
	}
	
	err2 = speed*ENC_COEFF + (Encoder2()-enc2)*ENC_CONST;
	up2 = err2*SPEED_COEFF+err2*err2*err2*SPEED_COEFF_CUBE;
	ui2 = ui2 + err2*SPEED_COEFF_I;
	ud2 = (err2_old - err2)*SPEED_COEFF_D;
	u2 = up2+ui2+ud2;
	err2_old = err2;
	if (err2==0)
	{
		ui2 = 0;
		
	}
	return u2;
}
float vel3(float speed, long int enc3)
{
	if (speed==100)
	{
		speed = 99;
	}
	if (speed==-100)
	{
		speed = -99;
	}
	
	err3 = speed*ENC_COEFF + (Encoder3()-enc3)*ENC_CONST;
	up3 = err3*SPEED_COEFF+err3*err3*err3*SPEED_COEFF_CUBE;
	ui3 = ui3 + err3*SPEED_COEFF_I;
	ud3 = (err3_old - err3)*SPEED_COEFF_D;
	u3 = up3+ui3+ud3;
	err3_old = err3;
	if (err3==0)
	{
		ui3 = 0;
		
	}
	return u3;
}


float vel4(float speed, long int enc4)
{
	if (speed==100)
	{
		speed = 99;
	}
	if (speed==-100)
	{
		speed = -99;
	}
	
	err4 = speed*ENC_COEFF + (Encoder4()-enc4)*ENC_CONST;
	up4 = err4*SPEED_COEFF+err4*err4*err4*SPEED_COEFF_CUBE;
	ui4 = ui4 + err4*SPEED_COEFF_I;
	ud4 = (err4_old - err4)*SPEED_COEFF_D;
	u4 = up4+ui4+ud4;
	err4_old = err4;
	if (err4==0)
	{
		ui4 = 0;
		
	}
	return u4;
}