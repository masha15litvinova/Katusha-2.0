#include "stm32f10x.h"

#ifdef __cplusplus
extern "C" {
#endif 
void delay(uint32_t time_delay);

#ifdef __cplusplus
}
#endif