#pragma once
#include "project_config.h"
#include "OLED_Driver.h"
#include "OLED_GFX.h"

class Display
{
    public:
        Display();
};
