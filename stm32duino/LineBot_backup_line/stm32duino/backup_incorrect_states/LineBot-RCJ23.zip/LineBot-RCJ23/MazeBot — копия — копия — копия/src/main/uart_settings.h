#pragma once

#include "project_config.h"

/***************************************************************************************************
 UART
***************************************************************************************************/

namespace uart
{

    const uint32_t rx_buffer_size = 255;

    const uint32_t tx_buffer_size = 255;

}



//#define UART_N1_ENABLE

//#define UART_N2_ENABLE

#define UART_N3_ENABLE

//#define UART_N4_ENABLE

//#define UART_N5_ENABLE

#define UART_N6_ENABLE
